-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: tarotbom
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `report`
--

DROP TABLE IF EXISTS `report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report` (
  `report_id` int unsigned NOT NULL AUTO_INCREMENT,
  `content` varchar(500) NOT NULL,
  `create_time` timestamp NULL DEFAULT NULL,
  `report_type` char(3) NOT NULL,
  `reported_id` int unsigned NOT NULL,
  `reporter_id` int unsigned NOT NULL,
  `room_id` int unsigned DEFAULT NULL,
  `status` char(3) NOT NULL,
  PRIMARY KEY (`report_id`),
  KEY `FKfitvul1cajkxhqdh3r97nxi3n` (`report_type`),
  KEY `FK6ovdlwgf174uw16m9cynvbgal` (`reported_id`),
  KEY `FK1uivt2jamt7slp3banldgnsef` (`reporter_id`),
  KEY `FK81kyf7whu1ovcesffi8vk8o4a` (`room_id`),
  KEY `FKkj2jvpn8txy6xowtl31q11dml` (`status`),
  CONSTRAINT `FK1uivt2jamt7slp3banldgnsef` FOREIGN KEY (`reporter_id`) REFERENCES `member` (`member_id`),
  CONSTRAINT `FK6ovdlwgf174uw16m9cynvbgal` FOREIGN KEY (`reported_id`) REFERENCES `member` (`member_id`),
  CONSTRAINT `FK81kyf7whu1ovcesffi8vk8o4a` FOREIGN KEY (`room_id`) REFERENCES `room` (`room_id`),
  CONSTRAINT `FKfitvul1cajkxhqdh3r97nxi3n` FOREIGN KEY (`report_type`) REFERENCES `code_detail` (`code_detail_id`),
  CONSTRAINT `FKkj2jvpn8txy6xowtl31q11dml` FOREIGN KEY (`status`) REFERENCES `code_detail` (`code_detail_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report`
--

LOCK TABLES `report` WRITE;
/*!40000 ALTER TABLE `report` DISABLE KEYS */;
INSERT INTO `report` VALUES (1,'타로를 읽지 않고 나갔습니다.','2024-02-10 05:00:00','S02',22,4,2,'D01'),(2,'상대방에게 욕설을 했습니다.','2024-03-05 06:30:00','S02',27,6,4,'D01'),(3,'성적 harassment을 당했습니다.','2024-04-15 00:20:00','S01',9,31,7,'D01'),(4,'상대방이 너무 짜증을 내었습니다.','2024-05-25 02:45:00','S02',33,11,9,'D01'),(5,'타로의 내용이 전혀 도움이 되지 않았습니다.','2024-06-12 01:15:00','S02',37,14,12,'D01'),(6,'타로를 강제로 읽으라고 했습니다.','2024-07-01 07:00:00','S02',16,39,14,'D01'),(7,'부적절한 언행을 했습니다.','2024-02-25 03:30:00','S02',20,42,17,'D01'),(8,'타로 결과가 너무 부정적이었습니다.','2024-03-20 04:00:00','S02',44,24,19,'D01'),(9,'사적인 질문을 너무 많이 했습니다.','2024-04-10 05:10:00','S02',35,47,22,'D01'),(10,'타로를 읽는 동안 매우 불쾌했습니다.','2024-05-05 06:20:00','S02',49,3,24,'D01'),(11,'타로를 읽는 방식이 매우 불쾌했습니다.','2024-06-30 07:40:00','S02',6,52,27,'D01'),(12,'타로를 읽은 후 너무 기분이 나빠졌습니다.','2024-07-15 08:10:00','S03',8,54,29,'D01'),(13,'과도한 요구를 했습니다.','2024-02-20 02:00:00','S02',7,67,47,'D01'),(14,'타로를 읽는 동안 무례했습니다.','2024-03-18 03:00:00','S02',11,67,51,'D01'),(15,'타로 결과에 대해 지나치게 불만을 표시했습니다.','2024-04-05 04:30:00','S02',16,67,56,'D01'),(16,'타로를 리딩하는 과정에서 불편함을 주었습니다.','2024-05-20 05:50:00','S02',66,5,61,'D01'),(17,'타로를 리딩 결과에 상처를 받았습니다.','2024-06-10 06:10:00','S02',5,66,65,'D01'),(18,'타로를 리딩 결과에 매우 실망했습니다.','2024-07-05 07:20:00','S02',9,66,70,'D01'),(19,'타로를 리딩 후 격하게 반응했습니다.','2024-02-15 08:00:00','S02',66,24,77,'D01');
/*!40000 ALTER TABLE `report` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-15 13:55:36
