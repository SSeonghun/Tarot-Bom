-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: tarotbom
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tarot_summary`
--

DROP TABLE IF EXISTS `tarot_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tarot_summary` (
  `member_id` int unsigned NOT NULL,
  `content` varchar(1000) NOT NULL,
  `create_time` timestamp NULL DEFAULT NULL,
  `card_id` int NOT NULL,
  PRIMARY KEY (`member_id`),
  KEY `FKd0p39mwoel48hxusw0awg7408` (`card_id`),
  CONSTRAINT `FKd0p39mwoel48hxusw0awg7408` FOREIGN KEY (`card_id`) REFERENCES `tarot_card` (`card_id`),
  CONSTRAINT `FKmyd5dtromivjsrjvid1v47ofk` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tarot_summary`
--

LOCK TABLES `tarot_summary` WRITE;
/*!40000 ALTER TABLE `tarot_summary` DISABLE KEYS */;
INSERT INTO `tarot_summary` VALUES (17,'새로운 시작과 무한한 가능성을 상징합니다. 새로운 여정이 곧 시작될 것입니다.','2024-08-06 15:00:00',1),(22,'창의성과 자기주도성을 발휘합니다. 강한 에너지를 가지고 문제를 해결할 수 있습니다.','2024-08-06 15:01:00',23),(23,'인내와 용기를 필요로 합니다. 어려운 상황에서도 우리는 결단력 있게 앞으로 나아가야 합니다.','2024-08-06 15:02:00',9),(27,'공정함과 정의를 상징합니다. 상황을 객관적으로 보고 올바른 결정을 내려야 합니다.','2024-08-06 15:03:00',12),(28,'권위와 안정성을 의미합니다. 현재 상황에 대한 강한 통제력을 가지고 있습니다.','2024-08-06 15:04:00',5),(29,'환상과 혼란을 나타냅니다. 여러 가지 옵션 중에서 가장 올바른 길을 찾아야 합니다.','2024-08-06 15:05:00',43),(31,'끈기와 인내를 의미합니다. 어려운 상황에서도 목표를 향해 계속 나아가야 합니다.','2024-08-06 15:06:00',31),(32,'사랑과 조화를 상징합니다. 중요한 관계가 형성되거나 강화될 것입니다.','2024-08-06 15:07:00',7),(33,'완전한 행복과 안정적인 가정생활을 의미합니다. 가족과의 관계가 매우 좋습니다.','2024-08-06 15:08:00',46),(34,'갑작스러운 변화와 혼란을 상징합니다. 변화에 적응하는 것이 중요합니다.','2024-08-06 15:09:00',17),(36,'진보를 나타냅니다. 현재 프로젝트나 목표에 긍정적인 결과가 예상됩니다.','2024-08-06 15:10:00',25),(37,'새로운 시작과 무한한 가능성을 의미합니다. 새로운 기회가 당신을 기다리고 있습니다.','2024-08-06 15:11:00',1),(38,'변화를 상징합니다. 오래된 것을 버리고 새로운 시작을 맞이하십시오.','2024-08-06 15:12:00',14),(39,'따뜻함과 에너지를 의미합니다. 주변 사람들과의 관계가 더욱 발전할 것입니다.','2024-08-06 15:13:00',35),(40,'새로운 감정의 시작을 상징합니다. 사랑과 감정적 연대가 강화될 것입니다.','2024-08-06 15:14:00',37),(41,'에너지와 추진력을 의미합니다. 목표를 향해 열정적으로 나아가야 합니다.','2024-08-06 15:15:00',34),(42,'도전과 싸움을 상징합니다. 현재의 어려운 상황에 맞서 싸울 때입니다.','2024-08-06 15:16:00',29),(43,'풍요와 번영을 의미합니다. 현재 상황에서 풍부한 자원을 활용하십시오.','2024-08-06 15:17:00',4),(44,'새로운 감정과 아이디어를 상징합니다. 감정적이고 창의적인 새로운 기회가 열릴 것입니다.','2024-08-06 15:18:00',47),(45,'리더십과 비전을 발휘합니다. 당신의 길을 확고히 하고 목표를 세우십시오.','2024-08-06 15:19:00',62),(46,'부담과 책임을 의미합니다. 현재의 책임을 감당하고 문제를 해결해야 합니다.','2024-08-06 15:20:00',32),(47,'감정의 균형과 통제를 나타냅니다. 감정적 안정과 통제가 필요합니다.','2024-08-06 15:21:00',50),(48,'새로운 감정과 아이디어를 상징합니다. 감정적이고 창의적인 새로운 기회가 열릴 것입니다.','2024-08-06 15:22:00',37),(49,'새로운 시작과 무한한 가능성을 상징합니다. 새로운 여정이 곧 시작될 것입니다.','2024-08-06 15:23:00',1),(50,'전통, 신앙 및 도덕적 가치를 중요하게 여깁니다. 깊은 이해와 지혜가 필요합니다.','2024-08-06 15:24:00',6),(51,'부담과 책임을 의미합니다. 현재 상황에서 큰 책임을 지고 있습니다.','2024-08-06 15:25:00',32),(52,'만족과 성취를 의미합니다. 원하는 것을 얻을 수 있는 시점입니다.','2024-08-06 15:26:00',45),(53,'따뜻함과 에너지를 상징합니다. 주변 사람들과의 관계가 개선될 것입니다.','2024-08-06 15:27:00',35),(54,'환상과 직관을 의미합니다. 상황을 깊이 이해하고 직관을 신뢰하십시오.','2024-08-06 15:28:00',19),(66,'삶의 어려움을 극복하고 더욱 강해지기 위해 내면의 탄력성, 연민, 자제력을 활용하세요','2024-08-06 15:28:00',9);
/*!40000 ALTER TABLE `tarot_summary` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-15 13:55:35
