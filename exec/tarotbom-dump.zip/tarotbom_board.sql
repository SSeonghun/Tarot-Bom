-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: tarotbom
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `board`
--

DROP TABLE IF EXISTS `board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board` (
  `board_id` int unsigned NOT NULL AUTO_INCREMENT,
  `board_type` varchar(255) NOT NULL,
  `comment_cnt` int DEFAULT '0',
  `content` varchar(1000) NOT NULL,
  `create_time` timestamp NULL DEFAULT NULL,
  `likely_cnt` int unsigned DEFAULT '0',
  `member_id` int unsigned DEFAULT NULL,
  `title` varchar(50) NOT NULL,
  `update_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`board_id`),
  KEY `FKr0jk40yxn30yh9u163k9wr0rk` (`board_type`),
  KEY `fk_board_member` (`member_id`),
  CONSTRAINT `fk_board_member` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FKr0jk40yxn30yh9u163k9wr0rk` FOREIGN KEY (`board_type`) REFERENCES `code_detail` (`code_detail_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board`
--

LOCK TABLES `board` WRITE;
/*!40000 ALTER TABLE `board` DISABLE KEYS */;
INSERT INTO `board` VALUES (1,'B01',3,'새로운 공지사항을 확인하세요. 중요한 정보가 포함되어 있습니다.','2024-03-19 15:00:00',0,1,'새로운 공지사항을 확인해 보세요.','2024-08-06 15:00:00'),(2,'B02',7,'이번 주의 카드 해석을 확인하세요. 새로운 통찰력을 얻을 수 있습니다.','2024-05-12 16:00:00',0,2,'이번 주 카드 해석을 통해 새로운 인사이트를 얻어보세요.','2024-08-06 16:00:00'),(3,'B03',5,'이번 주의 타로 리딩 경험을 공유합니다. 많은 교훈을 얻었습니다.','2024-05-16 17:00:00',0,3,'이번 주 타로 리딩 경험을 공유합니다.','2024-08-06 17:00:00'),(4,'B04',0,'기타 다양한 주제에 대한 토론을 나눕니다.','2024-06-02 15:00:00',0,4,'다양한 주제에 대해 자유롭게 이야기해요.','2024-08-06 18:00:00'),(5,'B01',1,'중요한 업데이트 사항을 확인하세요.','2024-06-06 16:00:00',0,5,'중요한 업데이트를 확인해 주세요.','2024-08-06 19:00:00'),(6,'B02',4,'카드 해석 결과를 분석합니다. 자세한 내용을 확인하세요.','2024-06-20 17:00:00',0,6,'카드 분석 결과를 자세히 살펴보세요.','2024-08-06 20:00:00'),(7,'B03',2,'타로 리딩 경험을 통해 얻은 교훈을 공유합니다.','2024-06-30 15:00:00',0,7,'타로 리딩 경험에서 배운 교훈을 나눠요.','2024-08-06 21:00:00'),(8,'B04',7,'기타 다양한 주제에 대한 자유로운 토론.','2024-07-01 16:00:00',0,7,'자유로운 주제에 대해 자유롭게 이야기해요.','2024-08-10 23:53:18'),(9,'B01',0,'중요한 공지사항입니다. 모든 회원이 확인해야 합니다.','2024-07-05 17:00:00',0,9,'중요한 공지가 있으니 확인해 주세요.','2024-08-06 23:00:00'),(10,'B02',8,'이번 주 카드 해석 내용을 확인하세요. 깊은 통찰력을 제공합니다.','2024-07-09 15:00:00',0,10,'이번 주 카드 해석에서 깊이 있는 인사이트를 얻어보세요.','2024-08-07 00:00:00'),(11,'B03',3,'최근 타로 리딩 경험을 공유합니다. 많은 것을 배웠습니다.','2024-07-12 16:00:00',0,11,'최근 타로 리딩 경험을 공유합니다.','2024-08-07 01:00:00'),(12,'B04',9,'기타 다양한 주제에 대한 자유로운 이야기 나눔.','2024-07-13 17:00:00',0,12,'자유롭게 다양한 이야기를 나눠요.','2024-08-07 02:00:00'),(13,'B01',2,'공지사항을 확인하세요. 중요한 정보가 포함되어 있습니다.','2024-07-14 15:00:00',0,13,'중요한 공지를 확인해 주세요.','2024-08-07 03:00:00'),(14,'B02',10,'이번 주의 카드 해석을 통해 새로운 통찰력을 얻으세요.','2024-07-18 16:00:00',0,14,'이번 주 카드 인사이트를 확인해 보세요.','2024-08-07 04:00:00'),(15,'B03',7,'타로 리딩 경험을 공유합니다. 많은 것을 배울 수 있습니다.','2024-07-29 17:00:00',0,15,'타로 리딩 경험을 나눠주세요.','2024-08-07 05:00:00'),(16,'B04',5,'기타 다양한 주제에 대한 토론을 나눕니다.','2024-08-01 15:00:00',0,16,'주제에 대해 자유롭게 이야기해요.','2024-08-07 06:00:00'),(17,'B01',1,'중요한 공지사항을 확인하세요.','2024-08-02 16:00:00',0,17,'중요한 공지를 다시 한 번 확인해 주세요.','2024-08-07 07:00:00'),(18,'B02',4,'카드 해석 결과를 분석합니다. 자세한 내용을 확인하세요.','2024-08-06 17:00:00',0,18,'카드 분석 결과를 심층적으로 살펴보세요.','2024-08-07 08:00:00'),(19,'B03',0,'타로 리딩 경험을 통해 얻은 교훈을 공유합니다.','2024-08-02 15:00:00',0,19,'타로 리딩에서 배운 교훈을 공유해요.','2024-08-07 09:00:00'),(20,'B04',3,'기타 다양한 주제에 대한 자유로운 토론.','2024-08-06 16:00:00',0,20,'다양한 주제에 대해 자유롭게 이야기해요.','2024-08-07 10:00:00'),(21,'B01',0,'중요한 공지사항입니다. 모든 회원이 확인해야 합니다.','2024-08-10 17:00:00',0,21,'회원 모두가 확인해야 할 공지입니다.','2024-08-07 11:00:00'),(22,'B02',6,'이번 주 카드 해석 내용을 확인하세요. 깊은 통찰력을 제공합니다.','2024-08-10 15:00:00',0,22,'이번 주 카드 인사이트를 깊이 있게 살펴보세요.','2024-08-07 12:00:00'),(23,'B03',8,'최근 타로 리딩 경험을 공유합니다. 많은 것을 배웠습니다.','2024-08-11 16:00:00',0,23,'최근 타로 리딩 인사이트를 확인해 보세요.','2024-08-07 13:00:00'),(24,'B03',0,'기타 다양한 주제에 대한 자유로운 이야기 나눔.','2024-08-15 17:00:00',0,24,'자유롭게 이야기하고 싶어요.','2024-08-10 23:47:44');
/*!40000 ALTER TABLE `board` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-15 13:55:36
