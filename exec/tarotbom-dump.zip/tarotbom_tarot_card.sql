-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: tarotbom
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tarot_card`
--

DROP TABLE IF EXISTS `tarot_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tarot_card` (
  `card_id` int NOT NULL,
  `card_name` varchar(50) DEFAULT NULL,
  `card_type` varchar(10) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `number` int DEFAULT NULL,
  PRIMARY KEY (`card_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tarot_card`
--

LOCK TABLES `tarot_card` WRITE;
/*!40000 ALTER TABLE `tarot_card` DISABLE KEYS */;
INSERT INTO `tarot_card` VALUES (1,'The Fool','major','자유로움, 순수함, 무계획','https://d2ovihsqke74ur.cloudfront.net/m00.jpg',0),(2,'The Magician','major','시작에 있음, 잠재능력, 창의적, 다재다능, 능숙함, 자기제어','https://d2ovihsqke74ur.cloudfront.net/m01.jpg',1),(3,'The High Priestess','major','여성성, 지적, 영적, 직감적, 비밀스러움, 이중적, 내성적','https://d2ovihsqke74ur.cloudfront.net/m02.jpg',2),(4,'The Empress','major','여성성, 물질적, 풍요로움, 현실적, 모성애','https://d2ovihsqke74ur.cloudfront.net/m03.jpg',3),(5,'The Empreror','major','권위적, 지배적, 자기중심적, 카리스마, 열정, 승부욕','https://d2ovihsqke74ur.cloudfront.net/m04.jpg',4),(6,'The Hierophont','major','권위적, 중재적, 신뢰감, 조언가','https://d2ovihsqke74ur.cloudfront.net/m05.jpg',5),(7,'The Lovers','major','매력적, 열정적, 호감, 끌림','https://d2ovihsqke74ur.cloudfront.net/m06.jpg',6),(8,'The Chariot','major','추진력, 주도적, 통제력, 승리, 자신감, 저돌적','https://d2ovihsqke74ur.cloudfront.net/m07.jpg',7),(9,'Strength','major','힘, 지혜, 절제력, 인내심, 통제력','https://d2ovihsqke74ur.cloudfront.net/m08.jpg',8),(10,'The Hermit','major','지혜, 내적 성찰, 현실성 없음, 홀로 생각함','https://d2ovihsqke74ur.cloudfront.net/m09.jpg',9),(11,'Wheel of Fortune','major','운명적, 행운, 새로운 시작, 변화','https://d2ovihsqke74ur.cloudfront.net/m10.jpg',10),(12,'Justice','major','공평함, 정의로운, 까다로운, 우유부단, 객관적','https://d2ovihsqke74ur.cloudfront.net/m11.jpg',11),(13,'The Hanged Man','major','희생적, 고통을 견딤, 인내심, 속박','https://d2ovihsqke74ur.cloudfront.net/m12.jpg',12),(14,'Death','major','죽음, 끝, 새로운 시작, 큰 변화, 개혁, 완전한 종결','https://d2ovihsqke74ur.cloudfront.net/m13.jpg',13),(15,'Temperance','major','절제력있는, 균형적, 중용, 통합적, 이해하는','https://d2ovihsqke74ur.cloudfront.net/m14.jpg',14),(16,'The Devil','major','속박, 집착, 불안, 중독','https://d2ovihsqke74ur.cloudfront.net/m15.jpg',15),(17,'The Tower','major','갑작스러움, 몰락, 사고, 충격, 급변화, 안 좋은 상황','https://d2ovihsqke74ur.cloudfront.net/m16.jpg',16),(18,'The Star','major','희망, 낙관, 창조적, 긍정적, 순수','https://d2ovihsqke74ur.cloudfront.net/m17.jpg',17),(19,'The Moon','major','갈등, 이중성, 혼란, 두려움, 불안, 의심','https://d2ovihsqke74ur.cloudfront.net/m18.jpg',18),(20,'The Sun','major','완성, 성취, 활력, 순수, 행복, 긍정, 목표 달성','https://d2ovihsqke74ur.cloudfront.net/m19.jpg',19),(21,'Judgement','major','구원받음, 보상받음, 심판받음, 결정을 알림, 기다리던 소식, 재회','https://d2ovihsqke74ur.cloudfront.net/m20.jpg',20),(22,'The World','major','완성, 성공, 통합, 목표 달성','https://d2ovihsqke74ur.cloudfront.net/m21.jpg',21),(23,'Ace of Wands','wand','새로운 시작, 호기심, 자신감, 처음, 직관적, 새로운 일, 준비된 시작','https://d2ovihsqke74ur.cloudfront.net/w01.jpg',1),(24,'Two of Wands','wand','야망, 큰 목표, 소식을 기다림, 좋은 소식, 먼 곳의 소식','https://d2ovihsqke74ur.cloudfront.net/w02.jpg',2),(25,'Three of Wands','wand','소식을 기다림, 성공의 꿈, 심사숙고, 무역, 거래','https://d2ovihsqke74ur.cloudfront.net/w03.jpg',3),(26,'Four of Wands','wand','안정, 번영과 평온, 가정과 결혼, 즐거운 시기','https://d2ovihsqke74ur.cloudfront.net/w04.jpg',4),(27,'Five of Wands','wand','싸움, 혼란스러움, 의견의 불일치, 경쟁','https://d2ovihsqke74ur.cloudfront.net/w05.jpg',5),(28,'Six of Wands','wand','승리, 성공, 좋은 소식, 정복함, 자신감이 넘침, 새 출발','https://d2ovihsqke74ur.cloudfront.net/w06.jpg',6),(29,'Seven of Wands','wand','방어적, 버티는, 타협하지 않음, 저항, 끈기','https://d2ovihsqke74ur.cloudfront.net/w07.jpg',7),(30,'Eight of Wands','wand','빠른 결정, 이동, 전진, 부지런함, 단기','https://d2ovihsqke74ur.cloudfront.net/w08.jpg',8),(31,'Nine of Wands','wand','고군분투, 기진맥진, 끈기와 인내','https://d2ovihsqke74ur.cloudfront.net/w09.jpg',9),(32,'Ten of Wands','wand','압박, 책임, 부담','https://d2ovihsqke74ur.cloudfront.net/w10.jpg',10),(33,'Page of Wands','wand','호기심, 활동적, 잠재력, 열정, 미숙함','https://d2ovihsqke74ur.cloudfront.net/w11.jpg',11),(34,'Knight of Wands','wand','열정, 모험심, 성취욕, 충동적, 강한 열정','https://d2ovihsqke74ur.cloudfront.net/w12.jpg',12),(35,'Queen of Wands','wand','성공함, 성공한 여성, 지배욕, 유능함','https://d2ovihsqke74ur.cloudfront.net/w13.jpg',13),(36,'King of Wands','wand','쟁취, 성공, 권위적, 직관적, 열정적, 정직함','https://d2ovihsqke74ur.cloudfront.net/w14.jpg',14),(37,'Ace of Cups','cup','새로운 시작, 안정, 기쁨, 이해심, 순수함, 자애로움','https://d2ovihsqke74ur.cloudfront.net/c01.jpg',1),(38,'Two of Cups','cup','결혼, 결합, 계약, 동맹, 교환, 협력, 동업','https://d2ovihsqke74ur.cloudfront.net/c02.jpg',2),(39,'Three of Cups','cup','축하, 화합, 즐거움, 축제, 모임, 경사','https://d2ovihsqke74ur.cloudfront.net/c03.jpg',3),(40,'Four of Cups','cup','권태감, 정체기, 요지부동, 태만, 변화를 거부함','https://d2ovihsqke74ur.cloudfront.net/c04.jpg',4),(41,'Five of Cups','cup','후회, 고통, 과거에 연연, 좌절, 낙담, 미련','https://d2ovihsqke74ur.cloudfront.net/c05.jpg',5),(42,'Six of Cups','cup','추억, 그리움, 향수를 느낌, 순수함, 동심, 기쁜 소식','https://d2ovihsqke74ur.cloudfront.net/c06.jpg',6),(43,'Seven of Cups','cup','혼란스러움, 갈등, 비현실적임, 유혹','https://d2ovihsqke74ur.cloudfront.net/c07.jpg',7),(44,'Eight of Cups','cup','포기함, 모두 버리고 떠남, 인식의 전환, 겸손','https://d2ovihsqke74ur.cloudfront.net/c08.jpg',8),(45,'Nine of Cups','cup','만족함, 선공함, 자신만만, 즐거움','https://d2ovihsqke74ur.cloudfront.net/c09.jpg',9),(46,'Ten of Cups','cup','행복, 가정, 사랑이 가득함, 경사, 성공','https://d2ovihsqke74ur.cloudfront.net/c10.jpg',10),(47,'Page of Cups','cup','서툰 감정, 순수함, 수줍음, 예술적, 감성이 여림, 성실함','https://d2ovihsqke74ur.cloudfront.net/c11.jpg',11),(48,'Knight of Cups','cup','부드러운 접근, 설득을 잘 함, 정보를 줌','https://d2ovihsqke74ur.cloudfront.net/c12.jpg',12),(49,'Queen of Cups','cup','배려, 헌신, 편안함, 공감함','https://d2ovihsqke74ur.cloudfront.net/c13.jpg',13),(50,'King of Cups','cup','성공함, 부드러움, 자애로움, 예술적, 관대한 권위','https://d2ovihsqke74ur.cloudfront.net/c14.jpg',14),(51,'Ace of Swords','sword','새로운 시작, 쟁취, 승리, 권력, 이겨냄, 승부욕이 강함','https://d2ovihsqke74ur.cloudfront.net/s01.jpg',1),(52,'Two of Swords','sword','갈등, 중용, 중립, 우유부단함','https://d2ovihsqke74ur.cloudfront.net/s02.jpg',2),(53,'Three of Swords','sword','마음의 상처, 아픔, 괴로움, 극심한 고통, 배신, 이별','https://d2ovihsqke74ur.cloudfront.net/s03.jpg',3),(54,'Four of Swords','sword','회복, 휴식, 은둔, 내적 성찰','https://d2ovihsqke74ur.cloudfront.net/s04.jpg',4),(55,'Five of Swords','sword','무리한 싸움, 빼앗김, 불명예, 망신, 갈등','https://d2ovihsqke74ur.cloudfront.net/s05.jpg',5),(56,'Six of Swords','sword','떠남, 진행, 포기하지 않음, 이동, 여행','https://d2ovihsqke74ur.cloudfront.net/s06.jpg',6),(57,'Seven of Swords','sword','비겁함, 불안정함, 죄의식, 간교함, 불명예, 사기꾼','https://d2ovihsqke74ur.cloudfront.net/s07.jpg',7),(58,'Eight of Swords','sword','구속, 의지 부족, 두려움, 끈기가 필요함','https://d2ovihsqke74ur.cloudfront.net/s08.jpg',8),(59,'Nine of Swords','sword','심적인 고통, 고뇌, 불안과 두려움, 우울','https://d2ovihsqke74ur.cloudfront.net/s09.jpg',9),(60,'Ten of Swords','sword','완전한 종결, 절망, 배신, 돌이킬 수 없음','https://d2ovihsqke74ur.cloudfront.net/s10.jpg',10),(61,'Page of Swords','sword','새로운 시작, 서투름, 어설픔, 민첩함, 경계심, 긴장','https://d2ovihsqke74ur.cloudfront.net/s11.jpg',11),(62,'Knight of Swords','sword','저돌적, 공격적, 리더쉽, 성급함','https://d2ovihsqke74ur.cloudfront.net/s12.jpg',12),(63,'Queen of Swords','sword','성공함, 결단력 있음, 강한 의지, 유능함, 독립적','https://d2ovihsqke74ur.cloudfront.net/s13.jpg',13),(64,'King of Swords','sword','성공, 명예, 권력, 가부장적, 자존심이 강함','https://d2ovihsqke74ur.cloudfront.net/s14.jpg',14),(65,'Ace of Pentacles','Pentacle','새로운 시작, 새로운 기회, 물질적 풍요, 번창','https://d2ovihsqke74ur.cloudfront.net/p01.jpg',1),(66,'Two of Pentacles','Pentacle','균형을 맞춤, 중재함, 의무적임, 동시 진행','https://d2ovihsqke74ur.cloudfront.net/p02.jpg',2),(67,'Three of Pentacles','Pentacle','완성되어감, 기술 발휘, 숙련, 협력자, 명예, 예술성','https://d2ovihsqke74ur.cloudfront.net/p03.jpg',3),(68,'Four of Pentacles','Pentacle','인색함, 물질욕, 소유욕, 집착, 융통성 없음, 구두쇠','https://d2ovihsqke74ur.cloudfront.net/p04.jpg',4),(69,'Five of Pentacles','Pentacle','가난함, 포기함, 궁핍함, 부도, 손실, 실패','https://d2ovihsqke74ur.cloudfront.net/p05.jpg',5),(70,'Six of Pentacles','Pentacle','베풂, 공정한 분배, 기부, 봉사, 박애주의','https://d2ovihsqke74ur.cloudfront.net/p06.jpg',6),(71,'Seven of Pentacles','Pentacle','고민, 미래를 계획함, 노력의 보상, 성장, 성과','https://d2ovihsqke74ur.cloudfront.net/p07.jpg',7),(72,'Eight of Pentacles','Pentacle','성실함, 꾸준함, 노력함, 결실, 장인 정신, 워커홀릭','https://d2ovihsqke74ur.cloudfront.net/p08.jpg',8),(73,'Nine of Pentacles','Pentacle','부유함, 풍요, 독립적, 현실적, 자연친화적','https://d2ovihsqke74ur.cloudfront.net/p09.jpg',9),(74,'Ten of Pentacles','Pentacle','풍요로움, 즐거움, 성공, 재력가, 주위의 도움','https://d2ovihsqke74ur.cloudfront.net/p10.jpg',10),(75,'Page of Pentacles','Pentacle','새로운 시작, 서투름, 잠재력, 조심스러움, 신중함','https://d2ovihsqke74ur.cloudfront.net/p11.jpg',11),(76,'Knight of Pentacles','Pentacle','신중함, 근면함, 성숙함, 책임감','https://d2ovihsqke74ur.cloudfront.net/p12.jpg',12),(77,'Queen of Pentacles','Pentacle','안정감, 편안함, 능력있음, 풍요로움, 자비로움','https://d2ovihsqke74ur.cloudfront.net/p13.jpg',13),(78,'King of Pentacles','Pentacle','성공, 성취, 큰 수익, 끈기, 인내','https://d2ovihsqke74ur.cloudfront.net/p14.jpg',14);
/*!40000 ALTER TABLE `tarot_card` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-15 13:55:35
